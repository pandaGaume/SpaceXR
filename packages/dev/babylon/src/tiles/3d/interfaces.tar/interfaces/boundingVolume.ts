export type BoxType = [number, number, number, number, number, number, number, number, number, number, number, number];
export type RegionType = [number, number, number, number, number, number];
export type SphereType = [number, number, number, number];

/**
 * A bounding volume that encloses a tile or its content. At least one bounding volume property is required. Bounding volumes include `box`, `region`, or `sphere`.
 */
export interface IBoundingVolume {
    /**
     * An array of 12 numbers that define an oriented bounding box.
     * The first three elements define the x, y, and z values for the center of the box.
     * The next three elements (with indices 3, 4, and 5) define the x axis direction and half-length.
     * The next three elements (indices 6, 7, and 8) define the y axis direction and half-length.
     * The last three elements (indices 9, 10, and 11) define the z axis direction and half-length.
     *
     * @minItems 12
     * @maxItems 12
     */
    box?: BoxType;
    /**
     * An array of six numbers that define a bounding geographic region in EPSG:4979 coordinates
     * with the order [west, south, east, north, minimum height, maximum height].
     * Longitudes and latitudes are in radians. The range for latitudes is [-PI/2,PI/2].
     * The range for longitudes is [-PI,PI]. The value that is given as the 'south' of the region shall not be larger than the value for the 'north' of the region. The heights are in meters above (or below) the WGS84 ellipsoid. The 'minimum height' shall not be larger than the 'maximum height'.
     *
     * @minItems 6
     * @maxItems 6
     */
    region?: RegionType;
    /**
     * An array of four numbers that define a bounding sphere. The first three elements define the x, y, and z values for the center of the sphere. The last element (with index 3) defines the radius in meters. The radius shall not be negative.
     *
     * @minItems 4
     * @maxItems 4
     */
    sphere?: SphereType;
}

export type IBoxType = [number, number, number, number, number, number, number, number, number, number, number, number];

export function AreBoxIntersect(a: IBoxType, b: IBoxType): boolean {
    for (let i = 0; i < 3; ++i) {
        const ai = 3 + i * 3;
        const aj = ai + 1;
        const ak = ai + 2;

        const aHalf = Math.sqrt(a[ai] ** 2 + a[aj] ** 2 + a[ak] ** 2);
        const bHalf = Math.sqrt(b[ai] ** 2 + b[aj] ** 2 + b[ak] ** 2);

        const aMin = a[i] - aHalf;
        const aMax = a[i] + aHalf;

        const bMin = b[i] - bHalf;
        const bMax = b[i] + bHalf;

        // Sort early if separated on this axis
        if (aMax < bMin || aMin > bMax) {
            return false;
        }
    }

    return true;
}
